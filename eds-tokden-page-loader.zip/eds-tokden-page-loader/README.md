# @eds-token/page-loader

A framework-agnostic loader animation package from the **Enterprise Design System (EDS)**.  
Provides a fixed 120×120px loading animation with built-in reduced-motion support, ready for use in React, Angular, Vanilla JavaScript, and AEM environments.

---

## 📦 What This Package Contains

After installing `@eds-token/page-loader`, you get:

- A compiled loader implementation
- A bundled `lottie-web` runtime
- Dual build formats:
  - CommonJS (`dist/index.js`)
  - ES Module (`dist/index.mjs`)
- TypeScript types (`dist/index.d.ts`)
- Documentation (`README.md`)

This package does *not* expose configuration knobs — behavior and size are fixed.

---

## 🚀 Installation (Frontend)

### Install from Artifactory

Ensure your `.npmrc` points the scope to your Artifactory registry:

```
# EDS Token scoped registry
@eds-token:registry=https://artifactory.yourcompany.com/npm
//artifactory.yourcompany.com/npm/:_authToken=${ARTIFACTORY_TOKEN}
```

Then run:

```bash
npm install @eds-token/page-loader
```

or with Yarn:

```bash
yarn add @eds-token/page-loader
```

---

## 🧩 Usage (Bundled JavaScript Environments)

In React, Angular, or another bundler environment:

```js
import { mountPageLoader } from '@eds-token/page-loader';

const cleanup = mountPageLoader(
  document.getElementById('loader-root')
);

// later, when done:
cleanup();
```

This works with Webpack, Vite, Rollup, and other modern JavaScript toolchains.

---

## ♿ Reduced Motion Support

This loader respects the user’s OS preference for reduced motion:

| Motion Preference            | Behavior                        |
|-----------------------------|---------------------------------|
| Normal                      | Animation plays and loops       |
| Prefers reduced motion      | Static first frame only         |

No extra configuration is required — this happens automatically.

---

## Using With AEM (No Bundler Required)

AEM developers do *not* need to install the npm package or use JavaScript modules.

Instead:

1. The build process produces a **pre-bundled clientlib ZIP**
2. Download that ZIP from Artifactory
3. Include those clientlibs in their templates
4. Call a simple global API to mount the loader

### What AEM Developers Need

We publish two artifacts for each release:

- `@eds-token/page-loader@X.Y.Z` — npm package
- `eds-token-page-loader-X.Y.Z.zip` — AEM clientlib bundle

The clientlib ZIP contains:

```
js/
  lottie_svg.min.js
  page-loader.bundle.js
  eds-page-loader.js
  eds-page-loader-init.js
.content.xml
```

#### lottie_svg.min.js  
The browser version of the Lottie runtime.

#### page-loader.bundle.js  
A browser-ready bundle that exposes the loader mount function globally.

#### eds-page-loader.js  
A wrapper script that exposes `EDSPageLoader.init()`.

#### eds-page-loader-init.js (optional)  
Auto-initializes the loader on DOM ready if `#loader-root` is present.

#### .content.xml  
AEM clientlib configuration metadata.

---

### Step-by-Step: Integrate in AEM

#### 1. Download the ZIP from Artifactory

Your platform team downloads:

```
eds-token-page-loader-X.Y.Z.zip
```

from your Artifactory artifacts repository.

#### 2. Unzip into an AEM Clientlib

Unzip into a clientlib path such as:

```
/etc/clientlibs/eds.token.page-loader/
```

The final structure should look like:

```
/etc/clientlibs/eds.token.page-loader/
  js/
    lottie_svg.min.js
    page-loader.bundle.js
    eds-page-loader.js
    eds-page-loader-init.js
  .content.xml
```

#### 3. Include the Clientlib in HTL

In your AEM HTL template:

```html
<sly data-sly-use.clientLib="${'granite:clientlibs'}"
     data-sly-call="${clientLib.js @ categories='eds.token.page-loader'}"/>
```

This loads all scripts on the page.

#### 4. Add a Loader Container

Wherever you need the loader:

```html
<div id="loader-root"></div>
```

#### 5. Initialize the Loader

You have two options:

**Manual Initialization**

```html
<script>
  EDSPageLoader.init('#loader-root');
</script>
```

**Automatic Initialization**

If your clientlib includes `eds-page-loader-init.js`, it will automatically mount the loader when the DOM is ready for an element with `id="loader-root"`.

---

## Example AEM Usage

```html
<div id="loader-root"></div>

<script>
  EDSPageLoader.init('#loader-root');
</script>
```

or simply:

```html
<div id="loader-root"></div>
```

if `eds-page-loader-init.js` is included in your clientlib for automatic mounting.

---

## Versioning Policy

This package follows semantic versioning:

- **Major** — breaking changes
- **Minor** — non-breaking enhancements
- **Patch** — bug fixes

Animation updates or behavior changes that affect UI should bump the major version.

---

## Support

For integration help, contact the Enterprise Design System team or your platform engineering lead.

