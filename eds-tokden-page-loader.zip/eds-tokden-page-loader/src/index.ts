export { mountPageLoader as default, mountPageLoader } from './loader';
