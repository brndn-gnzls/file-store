import lottie from 'lottie-web';
import loaderJson from './animations/loader.v1.json';

const FIXED_SIZE = 120; // confirmed by design

export function mountPageLoader(container: HTMLElement): () => void {
  if (!container) {
    throw new Error('Page loader requires a container element');
  }

  // enforce fixed size
  container.style.width = `${FIXED_SIZE}px`;
  container.style.height = `${FIXED_SIZE}px`;
  container.style.overflow = 'hidden';

  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const animation = lottie.loadAnimation({
    container,
    animationData: loaderJson,
    renderer: 'svg',
    loop: !prefersReducedMotion,
    autoplay: !prefersReducedMotion,
  });

  if (prefersReducedMotion) {
    // immediately pause on the first frame
    animation.goToAndStop(0, true);
  }

  return () => {
    animation.destroy();
  };
}
