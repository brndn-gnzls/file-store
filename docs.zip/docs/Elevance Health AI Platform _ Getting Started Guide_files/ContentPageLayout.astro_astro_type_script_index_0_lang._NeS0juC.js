import{i as e}from"./plausible.DeEn1NUa.js";e({domain:window.location.hostname,endpoint:"https://plausible.dev.elevancehealth.com/api/event",autoCapturePageviews:!0,outboundLinks:!0});
