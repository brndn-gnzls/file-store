# 🔁 Elevance EDS React Base Configuration

This repo contains our base React configuration for Elevance's Enterprise Design System.
