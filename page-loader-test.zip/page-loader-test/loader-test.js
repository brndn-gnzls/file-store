import { mountPageLoader } from './page-loader-dist/dist/index.mjs';

const container = document.getElementById('loader-root');

const cleanup = mountPageLoader(container);

// (optional) remove it after a few seconds
// setTimeout(cleanup, 5000);
