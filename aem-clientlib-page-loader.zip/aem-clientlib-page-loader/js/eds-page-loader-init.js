/**
 * Automatically mounts the loader when DOM is ready
 * if an element with id="loader-root" exists.
 */

document.addEventListener('DOMContentLoaded', function() {
    const root = document.getElementById('loader-root');
    if (root && typeof window.EDSPageLoader !== 'undefined') {
      window.EDSPageLoader.init(root);
    }
  });