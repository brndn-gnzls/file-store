/**
 * AEM Global Loader Wrapper
 * Include after: 
 *   1) lottie_svg.min.js
 *   2) page-loader.bundle.js
 */

(function(window) {
    if (window.EDSPageLoader) {
      return; // avoid redefinition
    }
  
    const EDSPageLoader = {};
  
    /**
     * Mounts the loader into the given container.
     * @param {string|HTMLElement} target - CSS selector or DOM element
     * @returns {Function} cleanup
     */
    EDSPageLoader.init = function(target) {
      let container;
  
      if (typeof target === 'string') {
        container = document.querySelector(target);
      } else if (target instanceof HTMLElement) {
        container = target;
      }
  
      if (!container) {
        console.error('EDSPageLoader: No valid container provided');
        return function noop() {};
      }
  
      if (typeof window.lottie === 'undefined') {
        console.error('EDSPageLoader: lottie-web must be loaded first');
        return function noop() {};
      }
  
      if (typeof window.__EDS_PAGE_LOADER_MOUNT__ !== 'function') {
        console.error(
          'EDSPageLoader: Mount function not found. ' +
          'Ensure page-loader.bundle.js loads before this script.'
        );
        return function noop() {};
      }
  
      return window.__EDS_PAGE_LOADER_MOUNT__(container);
    };
  
    window.EDSPageLoader = EDSPageLoader;
  })(window);